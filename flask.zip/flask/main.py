from flask import Flask, jsonify, request
from itertools import count

from model.tweet import Tweet
from model.user import User

tweets = []
tweet_ids = count(1)

app = Flask(__name__)


@app.get("/ping")
def ping():
    return jsonify({"response": "pong"})


@app.route("/tweet", methods=["POST"])
def create_tweet():
    tweet_json = request.get_json(silent=True)
    if not isinstance(tweet_json, dict) or not tweet_json.get("body") or not tweet_json.get("author"):
        return jsonify({"error": "JSON body must include non-empty 'body' and 'author' fields"}), 400

    tweet = Tweet(next(tweet_ids), tweet_json["body"], User(tweet_json["author"]))
    tweets.append(tweet)
    return jsonify({"id": tweet.id, "status": "Tweet created successfully"}), 201


@app.route("/tweet", methods=["GET"])
def read_tweet():
    return jsonify({
        "tweets": [
            {"id": tweet.id, "body": tweet.body, "author": tweet.author.username}
            for tweet in tweets
        ]
    })


@app.get("/tweet/<int:tweet_id>")
def read_one_tweet(tweet_id):
    tweet = next((item for item in tweets if item.id == tweet_id), None)
    if tweet is None:
        return jsonify({"error": "Tweet not found"}), 404
    return jsonify({"id": tweet.id, "body": tweet.body, "author": tweet.author.username})


@app.put("/tweet/<int:tweet_id>")
def update_tweet(tweet_id):
    tweet = next((item for item in tweets if item.id == tweet_id), None)
    if tweet is None:
        return jsonify({"error": "Tweet not found"}), 404

    tweet_json = request.get_json(silent=True)
    if not isinstance(tweet_json, dict) or not tweet_json.get("body") or not tweet_json.get("author"):
        return jsonify({"error": "JSON body must include non-empty 'body' and 'author' fields"}), 400

    tweet.body = tweet_json["body"]
    tweet.author = User(tweet_json["author"])
    return jsonify({"id": tweet.id, "body": tweet.body, "author": tweet.author.username})


@app.delete("/tweet/<int:tweet_id>")
def delete_tweet(tweet_id):
    tweet = next((item for item in tweets if item.id == tweet_id), None)
    if tweet is None:
        return jsonify({"error": "Tweet not found"}), 404

    tweets.remove(tweet)
    return "", 204


if __name__ == "__main__":
    app.run(debug=True)
