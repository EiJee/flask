from model.user import User


class Tweet:
    def __init__(self, tweet_id: int, body: str, author: User):
        self.id = tweet_id
        self.body = body
        self.author = author

  
